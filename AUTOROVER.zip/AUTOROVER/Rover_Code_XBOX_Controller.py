import serial
import time
import pygame


# The purpose of this code is to test whether or not the rover can be controlled from a USB connected XBOX controller

# This is the test code to determine whether or not the robot can be controlled.
ser = serial.Serial('/dev/serial0', 9600)

pygame.init()
joystick = pygame.joystick.Joystick(0)
joystick.init()

# motor speed variables
left_speed = 0
right_speed = 0

try:
    while True:
        # Control scheme with what to do
        for event in pygame.event.get():
            if event.type == pygame.JOYAXISMOTION:
                # Left joystick Y-axis controls forward/backward movement
                if event.axis == 1:
                    left_speed = -int(event.value * -100)
                    right_speed = -int(event.value * 100)
                # Right joystick X-axis controls turning left/right
                elif event.axis == 4:
                    left_speed = int(event.value * 100)
                    right_speed = -int(event.value * 100)

            # Handle button presses
            if event.type == pygame.JOYBUTTONDOWN:
                if event.button == 0: # A button
                    left_speed = -50
                    right_speed = 50
                elif event.button == 1: # B button
                    left_speed = 50
                    right_speed = -50
                elif event.button == 6: # Back button
                    left_speed = 0
                    right_speed = 0

        # Send motor commands to the Sabertooth
        ser.write(('M1:' + str(left_speed) + '\r').encode())
        ser.write(('M2:' + str(right_speed) + '\r').encode())

finally:
        # Stops the motors and closes serial connection
    ser.write(b'M1:0\r')
    ser.write(b'M2:0\r')
    ser.close()
    joystick.quit()



