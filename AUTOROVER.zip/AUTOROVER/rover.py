import time



# Define a function to execute motor commands based on direction and time
def execute_command(direction, duration):
    if direction == "fwd":
        ser.write(b'M1:100\r') # Set motor 1 speed to 100%
        ser.write(b'M2:100\r') # Set motor 2 speed to 100%
        time.sleep(duration)
    elif direction == "back":
        ser.write(b'M1:-100\r') # Set motor 1 speed to -100%
        ser.write(b'M2:-100\r') # Set motor 2 speed to -100%
        time.sleep(duration)
    elif direction == "right":
        ser.write(b'M1:100\r') # Set motor 1 speed to 100%
        ser.write(b'M2:-100\r') # Set motor 2 speed to -100%
        time.sleep(0.0088*duration) # Calculate the time it takes to turn right by x degrees
    elif direction == "left":
        ser.write(b'M1:-100\r') # Set motor 1 speed to -100%
        ser.write(b'M2:100\r') # Set motor 2 speed to 100%
        time.sleep(0.0088*duration) # Calculate the time it takes to turn left by x degrees
    else:
        print("Invalid direction command: {}".format(direction))

# Open the CSV file and read each line
with open('commands.csv') as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        direction = row[0]
        duration = int(row[1])
        execute_command(direction, duration)

# Stop the motors and close the serial connection
ser.write(b'M1:0\r') # Stop motor 1
ser.write(b'M2:0\r') # Stop motor 2
ser.close()
#In this code, the execute_command function takes a direction and a duration parameter and sends the appropriate motor commands to the Sabertooth motor controller. The with open('commands.csv') as csvfile: block reads each line of the CSV file and calls execute_command for each line. The stop commands at the end stop the motors and close the serial connection.

#The CSV file should be formatted with the


