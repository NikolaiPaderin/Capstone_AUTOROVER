import requests

def get_location():
    url = 'https://ipapi.co/json'
    response = requests.get(url)
    data = response.json()
    
    lat = data.get('latitude', 'N/A')
    long = data.get('longitude', 'N/A')
    
    print('latitude: ',lat)
    print('longitude: ', long)

get_location()