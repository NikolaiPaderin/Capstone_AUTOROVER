import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setup(4, GPIO.OUT)#front left
GPIO.setup(17, GPIO.OUT)#front middle
GPIO.setup(27, GPIO.OUT)#front right
GPIO.setup(22, GPIO.OUT)#left front
GPIO.setup(5, GPIO.OUT)#left back
GPIO.setup(6, GPIO.OUT)#right front
GPIO.setup(13, GPIO.OUT)#right back
GPIO.setup(19, GPIO.OUT)#back middle

GPIO.setup(18, GPIO.IN)#Front left
GPIO.setup(23, GPIO.IN)#front Middle
GPIO.setup(24, GPIO.IN)#Front Right
GPIO.setup(25, GPIO.IN)#Left Front
GPIO.setup(12, GPIO.IN)#Left Back
GPIO.setup(16, GPIO.IN)#Right Front
GPIO.setup(20, GPIO.IN)#Right Back
GPIO.setup(21, GPIO.IN)#Back middle


def measure_distance(TRIG_PIN, ECHO_PIN):
    # send a pulse to the sensor
    GPIO.output(TRIG_PIN, True)
    time.sleep(0.00001)
    GPIO.output(TRIG_PIN, False)

    # measure the time it takes for the pulse to bounce back
    start_time = time.time()
    pulse_start = time.time()
    pulse_end = time.time()
    while GPIO.input(ECHO_PIN) == 0:
        if time.time() - start_time > 0.1:
            return -1
        pulse_start = time.time()

    while GPIO.input(ECHO_PIN) == 1:
        if time.time() - start_time > 0.1:
            return -1
        pulse_end = time.time()

    # calculate distance in inches
    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 16880.486
    distance = round(distance, 2)

    return distance

    
    
while True:
    FL = measure_distance(4, 18)
    time.sleep(0.1)
    FM = measure_distance(17, 23)
    time.sleep(0.1)
    FR = measure_distance(27, 24)
    time.sleep(0.1)
    LF = measure_distance(22, 25)
    time.sleep(0.1)
    LB = measure_distance(5, 12)
    time.sleep(0.1)
    RF = measure_distance(6, 16)
    time.sleep(0.1)
    RB = measure_distance(13, 20)
    time.sleep(0.1)
    BM = measure_distance(19, 21)
    print("FL: ",FL, " FM: ", FM, "FR: ",FR)
    print("LF: ",LF," LB: ", LB, "RF: ",RF," RB: ",RB)
    print("BM: ",BM)
    time.sleep(1)