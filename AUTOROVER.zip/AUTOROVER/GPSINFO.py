import string
lat = 721
lon = 123
lon = str(lon)
lat = str(lat)
with open('GPSINFO.txt', 'w') as file:
    file.write(lat + lon)