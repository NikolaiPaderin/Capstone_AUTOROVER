import socket

# Create a socket object
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind the socket to a specific address and port
host = "100.96.1.38"
port = 12345
server_socket.bind((host, port))

# Listen for incoming connections
server_socket.listen(5)

print(f"Server listening on {host}:{port}")

while True:
    # Accept a connection from the client
    client_socket, addr = server_socket.accept()
    print(f"Connection from {addr}")

    # Send a message to the client
   # message_to_send = "Hello, client!"
   # client_socket.send(message_to_send.encode('utf-8'))

    # Receive data from the client
    while True:
        data = client_socket.recv(1024).decode('utf-8')
        print(f"Received from client: {data}")