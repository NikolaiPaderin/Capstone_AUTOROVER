import RPi.GPIO as GPIO
import serial
import time
import socket

# GPS configuration
ser = serial.Serial('/dev/ttyS0', 9600)
ser.flushInput()
ser.flushOutput()

# Server configuration
host = "100.96.1.38"  # Replace with the actual IP address or hostname
port = 12345

# Function to send data to the server
def send_to_server(data):
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((host, port))
        client_socket.send(data.encode('utf-8'))
        response = client_socket.recv(1024).decode('utf-8')
        client_socket.close()
        print(f"Sent to server: {data}")
        print(f"Server response: {response}")
    except Exception as e:
        print(f"Error sending data to the server: {str(e)}")

def send_at(command,back,timeout):
	rec_buff = ''
	ser.write((command+'\r\n').encode())
	time.sleep(timeout)
	if ser.inWaiting():
		time.sleep(0.01 )
		rec_buff = ser.read(ser.inWaiting())
	if rec_buff != '':
		if back not in rec_buff.decode():
			print(command + ' ERROR')
			print(command + ' back:\t' + rec_buff.decode())
			return 0
		else:
			
			#print(rec_buff.decode())
			
			#Additions to Demo Code Written by Tim!
			global GPSDATA
			#print(GPSDATA)
			GPSDATA = str(rec_buff.decode())
			Cleaned = GPSDATA[13:]
			
			#print(Cleaned)
			
			Lat = Cleaned[:2]
			SmallLat = Cleaned[2:11]
			NorthOrSouth = Cleaned[12]
			
			#print(Lat, SmallLat, NorthOrSouth)
			
			Long = Cleaned[14:17]
			SmallLong = Cleaned[17:26]
			EastOrWest = Cleaned[27]
			
			#print(Long, SmallLong, EastOrWest)   
			FinalLat = float(Lat) + (float(SmallLat)/60)
			FinalLong = float(Long) + (float(SmallLong)/60)
			
			if NorthOrSouth == 'S': FinalLat = -FinalLat
			if EastOrWest == 'W': FinalLong = -FinalLong
			
			print(FinalLat, FinalLong)
			
			#print(FinalLat, FinalLong)
			#print(rec_buff.decode())
			
			return 1
	else:
		print('GPS is not ready')
		return 0


def get_gps_position():
	rec_null = True
	answer = 0
	print('Start GPS session...')
	rec_buff = ''
	send_at('AT+CGPS=1,1','OK',1)
	time.sleep(2)
	while rec_null:
		answer = send_at('AT+CGPSINFO','+CGPSINFO: ',1)
		if 1 == answer:
			answer = 0
			if ',,,,,,' in rec_buff:
				print('GPS is not ready')
				rec_null = False
				time.sleep(1)
		else:
			print('error %d'%answer)
			rec_buff = ''
			send_at('AT+CGPS=0','OK',1)
			return False
		time.sleep(1.5)
def power_on(power_key):
	print('SIM7600X is starting:')
	GPIO.setmode(GPIO.BCM)
	GPIO.setwarnings(False)
	GPIO.setup(power_key,GPIO.OUT)
	time.sleep(0.1)
	GPIO.output(power_key,GPIO.HIGH)
	time.sleep(2)
	GPIO.output(power_key,GPIO.LOW)
	time.sleep(20)
	ser.flushInput()
	print('SIM7600X is ready')

def power_down(power_key):
	print('SIM7600X is loging off:')
	GPIO.output(power_key,GPIO.HIGH)
	time.sleep(3)
	GPIO.output(power_key,GPIO.LOW)
	time.sleep(18)
	print('Good bye')
# Main script
if __name__ == "__main__":
    power_on(power_key)
    try:
        while True:
            if get_gps_position():
                # Get GPS data
                gps_data = f"Latitude: {FinalLat}, Longitude: {FinalLong}"  # Modify this to your required format

                # Send GPS data to the server
                send_to_server(gps_data)

                # Wait for 5 seconds before the next GPS update
                time.sleep(5)
    except KeyboardInterrupt:
        pass
    finally:
        power_down(power_key)