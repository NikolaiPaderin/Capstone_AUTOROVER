import socket
import time

# Create a socket object
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind the socket to a specific address and port
host = "100.96.1.38"  # Replace with the actual IP address or hostname
port = 12345
server_socket.bind((host, port))

# Listen for incoming connections
server_socket.listen(5)

print(f"Server listening on {host}:{port}")
count = 0 
while True:
    # Accept a connection from the client
    client_socket, addr = server_socket.accept()
    print(f"Connection from {addr}")

    Receive data from the client
    data = client_socket.recv(1024).decode('utf-8')
    print(f"Received from client: {data}")

    # Process the received data (you can add your custom logic here)
    # In this example, we'll simply reverse the received data
    data = "-30.982123412, 96.197832213"
    # Send the reversed data back to the client
    client_socket.send(data.encode('utf-8'))
    print("data sent")
    time.sleep(5)

    # Close the client socket
client_socket.close()