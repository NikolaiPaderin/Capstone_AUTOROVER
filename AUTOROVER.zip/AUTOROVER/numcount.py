import RPi.GPIO as GPIO
import time

# Set up the GPIO pins
GPIO.setmode(GPIO.BCM)
GPIO.setup(18, GPIO.OUT) # 1088AS module data pin
GPIO.setup(23, GPIO.OUT) # 1088AS module clock pin
GPIO.setup(24, GPIO.OUT) # 1088AS module latch pin
GPIO.setup(25, GPIO.IN) # B103 joystick up pin
GPIO.setup(12, GPIO.IN) # B103 joystick down pin

# Define some constants
NUM_DIGITS = 3
DELAY = 0.1

# Initialize the 1088AS module
def init_1088AS():
    GPIO.output(23, GPIO.LOW)
    GPIO.output(24, GPIO.LOW)
    for i in range(8):
        GPIO.output(18, GPIO.LOW)
        GPIO.output(18, GPIO.HIGH)
        GPIO.output(18, GPIO.LOW)
        GPIO.output(18, GPIO.LOW)
        GPIO.output(23, GPIO.HIGH)
        GPIO.output(23, GPIO.LOW)
    GPIO.output(24, GPIO.HIGH)
    GPIO.output(24, GPIO.LOW)

# Display a number on the 1088AS module
def display_1088AS(number):
    digits = [int(digit) for digit in str(number).zfill(NUM_DIGITS)]
    GPIO.output(23, GPIO.LOW)
    GPIO.output(24, GPIO.LOW)
    for i in range(NUM_DIGITS):
        GPIO.output(18, GPIO.LOW)
        GPIO.output(18, digits[NUM_DIGITS - 1 - i])
        GPIO.output(18, GPIO.HIGH)
        GPIO.output(18, GPIO.LOW)
        GPIO.output(23, GPIO.HIGH)
        GPIO.output(23, GPIO.LOW)
    GPIO.output(24, GPIO.HIGH)
    GPIO.output(24, GPIO.LOW)

# Initialize the 1088AS module and display 0
init_1088AS()
display_1088AS(0)

# Initialize the current number to 0
current_number = 0

# Main loop
while True:
    # Check for joystick movement
    if GPIO.input(25):
        # Joystick up, increment the current number
        current_number = (current_number + 1) % 1000
        display_1088AS(current_number)
        time.sleep(DELAY)
    elif GPIO.input(12):
        # Joystick down, decrement the current number
        current_number = (current_number - 1) % 1000
        display_1088AS(current_number)
        time.sleep(DELAY)
