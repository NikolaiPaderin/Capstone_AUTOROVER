import subprocess
import time

# Command to start Minicom with the desired configuration
minicom_command = "minicom -D /dev/ttyS0"  # Replace with your serial port

# Start Minicom as a subprocess
minicom_process = subprocess.Popen(minicom_command, shell=True)

# Wait for Minicom to initialize (adjust the sleep time as needed)
time.sleep(2)

# Send a command to Minicom
command_to_send = "AT+CGPSINFO\r"  # Replace with your command
minicom_process.stdin.write(command_to_send.encode('utf-8'))
minicom_process.stdin.flush()

# Wait for the response (adjust the sleep time as needed)
time.sleep(2)

# Read th response from Minicom
response = minicom_process.stdout.read().decode('utf-8')
print("Response:", response)

# Close Minicom
minicom_process.stdin.write(b"exit\r")
minicom_process.stdin.flush()

# Wait for Minicom to exit
minicom_process.wait()
